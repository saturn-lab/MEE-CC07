# MEE-2019A-CC07

制造工程体验-CC07-单元

# 教师

[陈震](http://www.icenter.tsinghua.edu.cn/faculty/chenzhen/)、[周晋](http://www.icenter.tsinghua.edu.cn/faculty/zhoujin/)、马晓东、章屹松、刘娟蕾、郭敏、王浩宇

